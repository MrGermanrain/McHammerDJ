<?php
echo (rand(10, 30) . "<br>");
echo (rand(10, 30) . "<br>");
echo (rand(10, 30) . "<br>");
echo (rand(10, 30) . "<br>");
echo (rand(10, 30) . "<br>");
echo (rand(10, 30) . "<br>");
echo (rand(10, 30) . "<br>");
echo (rand(10, 30) . "<br>");
echo (rand(10, 30) . "<br>");
echo (rand(10, 30) . "<br>");
echo (rand(10, 30) . "<br>");
echo (rand(10, 30) . "<br>");
echo (rand(10, 30) . "<br>");
echo (rand(10, 30) . "<br>");
echo (rand(10, 30) . "<br>");
echo (rand(10, 30) . "<br>");
echo (rand(10, 30) . "<br>");
echo (rand(10, 30) . "<br>");
echo (rand(10, 30) . "<br>");
echo (rand(10, 30) . "<br>");
echo (rand(10, 30) . "<br>");
echo (rand(10, 30) . "<br>");
echo (rand(10, 30) . "<br>");
echo (rand(10, 30) . "<br>");
echo (rand(10, 30) . "<br>");
echo (rand(10, 30) . "<br>");
echo (rand(10, 30) . "<br>");

?>