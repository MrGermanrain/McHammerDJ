<?php
error_reporting(0);

// $server="localhost";
// $user="spymonkc_test";
// $password="aryan77998246";
// $db="spymonkc_test";

$server="localhost";
$user="root";
$password="";
$db="boot";

$conn=mysql_connect($server,$user,$password);
mysql_select_db("$db");



?>